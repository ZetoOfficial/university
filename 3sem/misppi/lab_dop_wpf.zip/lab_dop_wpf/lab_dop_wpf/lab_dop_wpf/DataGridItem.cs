namespace lab_dop_wpf;

public class DataGridItem
{
    public double Number { get; set; }

    public DataGridItem(double n)
    {
        Number = n;
    }
}